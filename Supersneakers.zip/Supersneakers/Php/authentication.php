<?php

session_start();





$username = $_POST['username'];

$password = $_POST['password'];




$isAuthenticated = validateUser($username, $password);



if ($isAuthenticated) {

   

    $_SESSION['username'] = $username;

    $_SESSION['logged_in'] = true;

    


    header("Location: home.php");

    exit();

} else {


    $_SESSION['login_error'] = "Invalid username or password";

    header("Location: login.php");

    exit();

}



function validateUser($username, $password) {

    

    $storedUsername = 'user';
    $storedPassword = password_hash('password', PASSWORD_DEFAULT);

    

    if ($username === $storedUsername && password_verify($password, $storedPassword)) {

        return true;

    } else {

        return false;

    }

}

?>