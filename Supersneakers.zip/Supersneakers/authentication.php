<?php

session_start();





$username = $_POST['email'];

$password = $_POST['psw'];




$isAuthenticated = validateUser($username, $password);



if ($isAuthenticated) {

   

    $_SESSION['email'] = $username;

    $_SESSION['logged_in'] = true;

    


    header("Location: index.php");

    exit();

} else {


    $_SESSION['login_error'] = "Invalid username or password";

    header("Location: index.php");

    exit();

}



function validateUser($username, $password) {

    

    $storedUsername = 'user';
    $storedPassword = password_hash('password', PASSWORD_DEFAULT);

    

    if ($username === $storedUsername && password_verify($password, $storedPassword)) {

        return true;

    } else {

        return false;

    }

}

?>